package com.pb.demo;

import java.util.Random;

public class Kick {
	
	public Integer shoot() {
		return (int) Math.round( Math.random() )  ;
	}
}
