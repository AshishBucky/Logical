package com.ip.phase2;

public class Shoppingcart {

	public static void main(String[] args) {
		new Display();
	}

}
