package com.ip.phase2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Cart {

	//List<Product> cartItems = new ArrayList<Product>();
	Map<Product,Integer> cItems=new HashMap<>();
	
	public void addProductToCartByPID(int pid) {
		Product product = getProductByProductID(pid);
		addToCart(product);
	}

	private Product getProductByProductID(int pid) {
		Product product = null;
		List<Product> products = new ProductsAvailable().getProductsAvailable();
		for (Product prod : products) {
			if (prod.getPid() == pid) {
				product = prod;
				break;
			}
		}
		return product;
	}

	public void removeProductByPID(int pId) {
//		Product prod = getProductByProductID(pid);
//		cartItems.remove(prod);
		
		
		for (Entry<Product, Integer> entry : cItems.entrySet()) {
			Product p=entry.getKey();
			if(p.getPid()==pId)
				cItems.put(p, entry.getValue() > 0 ? entry.getValue()-1 : 0 );
			
		}
	}

	ProductsAvailable proAvl = new ProductsAvailable();

	
	private void addToCart(Product product) {
		System.out.println("add to cart start===");
		Integer pId=product.getPid();
		if(cItems.size()<=0)
			cItems.put(product, 1);
		else {
			for (Entry<Product, Integer> entry : cItems.entrySet()) {
				Product p = entry.getKey();
				if (p.getPid() == pId)
					cItems.put(product, entry.getValue() + 1);
				System.out.println(entry.getKey() + " " + entry.getValue());
			}
		}
		
		//cItems.put(product, cItems.containsKey(pId) ? cItems.get(pId) + 1 : 1);
		
		//cartItems.add(product);
	}
	void printCartItems() {
//		for (Product prod : cartItems) {
//			System.out.println(prod.getPname()+ " "+prod.getPrice()+" "+prod.getStock());
//		}
		
		for (Entry<Product, Integer> entry : cItems.entrySet()) {
			Product p=entry.getKey();
			System.out.println(p.getPname()+ " "+p.getPrice()+" COUNT:"+entry.getValue());
		}
		

	}
}
